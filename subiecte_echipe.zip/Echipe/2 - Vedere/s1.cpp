/*
 * Author: Bogdan Iordache
 * Time Complexity: O(N)
 */
#include <algorithm>
#include <cassert>
#include <cmath>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;

typedef pair<int, int> Frac;
typedef pair<int, int> Point;

const double EPS = 1e-6;

Frac compute_slope(const Point &p1, const Point &p2) {
  return Frac(p2.second - p1.second, p2.first - p1.first);
}

int compare_fracs(const Frac &frac1, const Frac &frac2) {
  int sign = (frac1.second < 0 ? -1 : 1) * (frac2.second < 0 ? -1 : 1);
  long long left = 1LL * frac1.first * frac2.second;
  long long right = 1LL * frac1.second * frac2.first;
  return (left == right ? 0 : (left < right ? -1 : 1)) * sign;
}

double intersect_with_vertical(const Point &p1, const Point &p2, int x) {
  return 1.0 * (x - p1.first) * (p2.second - p1.second) /
             (p2.first - p1.first) +
         p1.second;
}

Point solve(int n, const vector<int> &heights) {
  Frac best_slope;
  int best_idx = -1;
  vector<double> best_y_left;
  best_y_left.reserve(n);
  best_y_left.push_back(heights[0]);
  for (int i = 1; i < n; ++i) {
    Frac slope = compute_slope(Point(1, heights[0]), Point(i + 1, heights[i]));
    if (best_idx == -1 || compare_fracs(slope, best_slope) > 0) {
      best_slope = slope;
      best_idx = i;
    }
    best_y_left.push_back(intersect_with_vertical(
        Point(1, heights[0]), Point(best_idx + 1, heights[best_idx]), i + 1));
  }

  best_idx = -1;
  vector<double> best_y_right;
  best_y_right.reserve(n);
  best_y_right.push_back(heights.back());
  for (int i = n - 2; i >= 0; --i) {
    Frac slope =
        compute_slope(Point(n, heights[n - 1]), Point(i + 1, heights[i]));
    if (best_idx == -1 || compare_fracs(slope, best_slope) < 0) {
      best_slope = slope;
      best_idx = i;
    }
    best_y_right.push_back(
        intersect_with_vertical(Point(n, heights[n - 1]),
                                Point(best_idx + 1, heights[best_idx]), i + 1));
  }
  reverse(best_y_right.begin(), best_y_right.end());

  Point sol;
  for (int i = 0; i < n; ++i) {
    double y = max(best_y_left[i], best_y_right[i]);
    if (abs(y - round(y)) < EPS) {
      y = round(y);
    } else {
      y = ceil(y);
    }

    if (i == 0 || sol.second > int(y)) {
      sol = Point(i + 1, int(y));
    }
  }

  return sol;
}

int main() {
#ifndef LOCAL
  ifstream cin("vedere.in");
  ofstream cout("vedere.out");
#endif

  int n;
  cin >> n;
  assert(1 <= n && n <= 100000);
  vector<int> heights(n);
  for (auto &h : heights) {
    cin >> h;
    assert(1 <= h && h <= 1000000000);
  }

  Point res = solve(n, heights);
  assert(1 <= res.first && res.first <= n);
  assert(1 <= res.second && res.second <= 1000000000);
  cout << res.first << ' ' << res.second << '\n';

  return 0;
}

