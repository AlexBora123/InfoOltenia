#include <fstream>
#include <cmath>
#include <climits>
#include <vector>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include <bitset>
#include <map>
#include <cstring>
#include <algorithm>
#include <cfloat>

#define NMAX 100003
using namespace std;

ifstream fin("vedere.in");
ofstream fout("vedere.out");

int n, k;
int heights[NMAX];
double panteStanga[NMAX], panteDreapta[NMAX];
int pozitiiStanga[NMAX], pozitiiDreapta[NMAX];

double intersectia_pe_verticala(int x1, int y1, int x2, int y2, int x) {
	//y-y1 = panta * (x - x1/x2-x1)
	return 1.0 * (x - x1) * (y2 - y1) /
		(x2 - x1) +
		y1;
}

int main() {
	fin >> n;
	for (int i = 1; i <= n; i++)
	{
		fin >> heights[i];
	}

	double pantaStanga = -DBL_MAX, pantaDreapta = DBL_MAX;
	int minimStanga = 1, minimDreapta = n;

	panteStanga[1] = 0;
	pozitiiStanga[1] = 1;
	for (int i = 2; i <= n; i++)
	{
		double panta = 1.0 * (heights[i] - heights[1]) / (i - 1);
		if (panta > pantaStanga)
		{
			pantaStanga = panta;
			minimStanga = i;
		}
		panteStanga[i] = pantaStanga;
		pozitiiStanga[i] = minimStanga;
	}

	panteDreapta[n] = 0;
	pozitiiDreapta[n] = n;
	for (int i = n - 1; i >= 1; i--)
	{
		double panta = 1.0 * (heights[n] - heights[i]) / (n - i);
		if (panta <= pantaDreapta)
		{
			pantaDreapta = panta;
			minimDreapta = i;
		}
		panteDreapta[i] = pantaDreapta;
		pozitiiDreapta[i] = minimDreapta;
	}

	int xMin = 1;
	int yMin = INT_MAX;
	double pantaVarfuri = 1.0 * (heights[n] - heights[1]) / (n - 1);

	if (pantaStanga <= pantaVarfuri) {
		if (heights[n] < heights[1]) {
			xMin = n;
		}
		yMin = min(heights[n], heights[1]);
	}
	//fout << xMin << " " << yMin << endl;
	//fout << pantaStanga << " " << pantaVarfuri << endl;
	for (int i = 1; i <= n; i++)
	{
		double v1 = -DBL_MAX;
		double v2 = -DBL_MAX;
		if (i != 1)
		{
			v1 = intersectia_pe_verticala(1, heights[1], pozitiiStanga[i], heights[pozitiiStanga[i]], i);
		}
		if (i != n)
		{
			v2 = intersectia_pe_verticala(n, heights[n], pozitiiDreapta[i], heights[pozitiiDreapta[i]], i);
		}
		
		double valMaxima = max(v1, v2);
		if (ceil(valMaxima) < yMin)
		{
			yMin = ceil(valMaxima);
			xMin = i;
		}
		//fout << v1 << " " << v2 <<" yMin: "<< yMin << pozitiiDreapta[i]  <<" "<< pozitiiStanga[i] << endl;

	}
	fout << xMin << " " << yMin << endl;

	return 0;
}

