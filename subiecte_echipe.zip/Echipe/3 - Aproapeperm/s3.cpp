#include <fstream>

using namespace std;
int x[100], f[100], n, sol;

int cont(int k) {
    if (x[k] != k && x[k] != k-1 && x[k] != k+1)
        return 0;
    if (k >= 3 && x[k] == k && x[k-1] == k-1 && x[k-2] == k-2)
        return 0;
    return 1;
}

void backtrack(int k) {
    if (k > n) {
        sol++;
    } else {
        for (int i=1;i<=n;i++) {
            if (f[i] == 0) {
                f[i] = 1;
                x[k] = i;
                if (cont(k))
                    backtrack(k+1);
                f[i] = 0;
            }
        }
    }
}

int main () {
    ifstream fin("aproapeperm.in");
    ofstream fout("aproapeperm.out");
    fin>>n;
    backtrack(1);
    fout<<sol;


    return 0;
}


