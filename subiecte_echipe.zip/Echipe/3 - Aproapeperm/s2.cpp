#include <fstream>

#define modulo 1000000007

using namespace std; 

ifstream fin ("aproapeperm.in");
ofstream fout ("aproapeperm.out");

int dperm[100000][3][3];

int solutie, n;

bool verif(int pos, int s1, int s2, int s3) {
    int val1 = pos - 2 + s1 - 1; // valoarea de pe pozitia (pos - 2)
    int val2 = pos - 1 + s2 - 1; // valoarea de pe pozitia (pos - 1)
    int val3 = pos + s3 - 1; // valoarea de pe pozitia pos
    if (val1 < 0 || val1 >= n || val2 < 0 || val2 >= n || val3 < 0 || val3 >= n) 
        return false;
    
    if (val1 == pos - 2 && val2 == pos - 1 && val3 == pos)
        return false;

    if (val1 == val2 || val1 == val3 || val2 == val3)
        return false;
  
    return true;
}

int main () {
    fin >> n;

    dperm[1][1][1] = dperm[1][1][2] = dperm[1][2][0] = dperm[1][2][2] = 1;

    for (int i = 2; i < n; ++i) {
        for (int s1 = 0; s1 <= 2; ++s1)
            for (int s2 = 0; s2 <= 2; ++s2)
                for (int s3 = 0; s3 <= 2; ++s3) 
                    if (verif(i, s1, s2, s3)) {
                        dperm[i][s2][s3] = (dperm[i][s2][s3] + dperm[i-1][s1][s2]) % modulo;
                    }
    }

    for (int s1 = 0; s1 <= 2; ++s1)
        for (int s2 = 0; s2 <= 2; ++s2)
            solutie = (solutie + dperm[n - 1][s1][s2]) % modulo;

    fout << solutie << "\n";

    return 0;
}

