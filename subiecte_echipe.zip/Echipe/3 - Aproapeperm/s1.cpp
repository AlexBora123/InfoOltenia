#include<fstream>
using namespace std;

ifstream in("aproapeperm.in");
ofstream out("aproapeperm.out");

const int DIM = 1e5 + 5;
const int MOD = 1e9 + 7;

int dp[DIM][3][3];

int n;

bool checkpos(int p, int v) {
  p += v - 1;
  if (p < 1 || p > n)
    return false;
  return true;
}

int getpos(int p, int v) {
  p += v - 1;
  return p;
}

bool checktuple(int p, int v1, int v2, int v3) {
  if (!checkpos(p-2, v1) || !checkpos(p-1, v2) || !checkpos(p, v3))
    return false;

  int pos1 = getpos(p-2, v1);
  int pos2 = getpos(p-1, v2);
  int pos3 = getpos(p, v3);

  if (pos1 == pos2 || pos2 == pos3 || pos1 == pos3)
    return false;
  if (pos1 == p-2 && pos2 == p-1 && pos3 == p)
    return false;
  
  return true;
}

int main()
{
  in >> n;

  if (n == 1) {
    out << 1 << endl;
    return 0;
  }

  for (int i1 = 0; i1 <= 2; ++i1) {
    for (int i2 = 0; i2 <= 2; ++i2) {
      if (checkpos(1, i1) && checkpos(2, i2) && 1+i1-1 != 2+i2-1) {
        dp[2][i1][i2] = 1;
      }
    }
  }

  for (int p = 3; p <= n; ++p) {
    for (int i1 = 0; i1 <= 2; ++i1) {
      for (int i2 = 0; i2 <= 2; ++i2) {
        for (int i3 = 0; i3 <= 2; ++i3) {
          if (checktuple(p, i1, i2, i3)) {
            dp[p][i2][i3] = (dp[p][i2][i3] + dp[p-1][i1][i2]) % MOD;
          }
        }
      }
    }
  }

  int answer = 0;
  for (int i1 = 0; i1 <= 2; ++i1) {
    for (int i2 = 0; i2 <= 2; ++i2) {
      answer = (answer + dp[n][i1][i2]) % MOD;
    }
  }

  out << answer << endl;

  return 0;
}

