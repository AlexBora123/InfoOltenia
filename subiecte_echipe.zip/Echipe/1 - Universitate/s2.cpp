#include <fstream>
#include <unordered_set>

using namespace std;

ifstream fin ("universitate.in");
ofstream fout("universitate.out");

unordered_set<int> studenti;

int nr_studenti;

void adauga(int id) {
    studenti.insert(id);
}

void scoate(int id) {
    studenti.erase(studenti.find(id));
}

void printeaza() {
    for (auto it : studenti){
        fout << it << " ";
    }
    fout << "\n";
}

int main () {
    int k;
    fin >> k;

    int an, actiune, id;
    fin >> an >> actiune >> id;
    int eveniment = 1;

    for (int anCurent = 1088; anCurent <= 2024; ++anCurent) {
        while (an <= anCurent) {
            if (actiune == 0) {
                adauga(id);
            } else {
                scoate(id);
            }
            eveniment++;
            if (eveniment <= k) {
                fin >> an >> actiune >> id;
            } else 
                an = 2025;
        }
        printeaza();
    }
}

