/* Author: Bogdan Iordache
 * Time Complexity: O(k)
 */
#include <cassert>
#include <fstream>
#include <unordered_set>
using namespace std;

int main() {
	ifstream cin("universitate.in");
    ofstream cout("universitate.out");

    int k; assert(cin >> k);
    assert(0 <= k && k <= 1000000);
    int y, a, s; assert(cin >> y >> a >> s);
    assert(1088 <= y && y <= 2024);
    assert(0 <= a && a <= 1);
    assert(0 <= s && s <= 1000000);
    k--;
    unordered_set<int> students;
    for (int year = 1088; year <= 2024; ++year) {
        while (y == year) {
            if (a == 0) {
                assert(students.find(s) == students.end());
                students.insert(s);
            }
            else {
                 assert(students.find(s) != students.end());
                 students.erase(s);
            }

            if (k) {
                int yy = y;
                cin >> y >> a >> s;
                assert(1088 <= y && y <= 2024);
                assert(0 <= a && a <= 1);
                assert(0 <= s && s <= 1000000);
                assert(yy <= y);
                k--;
            }
            else break;
        }

        assert(students.size() <= 1000);
        for (auto&& s : students) 
            cout << s << " ";
        cout << "\n";
    }

	return 0;
}

