#include <fstream>
#include <cmath>
using namespace std;
int n, r, sol, i, x;
int main () {
    ifstream fin ("divpar.in");
    ofstream fout("divpar.out");

    fin>>n;
    for (i=1;i<=n;i++) {
        fin>>x;
        r = (int)sqrt(x);
        if (r*r != x)
            sol++;
    }
    fout<<sol<<"\n";
}
