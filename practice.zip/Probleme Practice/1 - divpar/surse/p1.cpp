#include <fstream>
#include <cassert>
using namespace std;
int n, x, imp, sol, i, j;
int main () {
    ifstream fin ("divpar.in");
    ofstream fout("divpar.out");

    fin>>n;
    assert(1 <= n && n <= 1000);
    for (i=1;i<=n;i++) {
        fin>>x;
        assert(1 <= x && x < 100000000);
        imp = 0;
        for (j=1;j<=x/j;j++)
            if (x%j == 0) {
                if (j == x/j)
                    imp = 1;
            }
        if (imp == 0)
            sol++;
    }
    fout<<sol<<"\n";
}
