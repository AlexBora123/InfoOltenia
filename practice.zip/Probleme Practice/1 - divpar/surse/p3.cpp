#include <fstream>
#include <cmath>
using namespace std;
int n, nr, sol, i, j, x;
int main () {
    ifstream fin ("divpar.in");
    ofstream fout("divpar.out");

    fin>>n;
    for (i=1;i<=n;i++) {
        fin>>x;
        nr = 1;
        for (j=1;j<=x/2;j++)
            if (x%j == 0)
                nr++;
        if (nr % 2 == 0)
            sol++;
    }
    fout<<sol<<"\n";
}
