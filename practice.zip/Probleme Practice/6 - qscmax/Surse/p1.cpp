#include <fstream>
#include <iostream>
#include <cassert>
#define DIM 100010
#define INF 1000000
#define VM 3
using namespace std;
ifstream fin ("qscmax.in");
ofstream fout("qscmax.out");


int a[4*DIM][VM+1][VM+1];
int sol[VM+1][VM+1], saux[VM+1][VM+1];
int n, m, A, B, p, x, M, first, op;
int v[DIM];
void upd(int r[VM+1][VM+1], int a[VM+1][VM+1], int b[VM+1][VM+1]) {
    for (int i=0;i<=VM;i++)
        for (int j=i;j<=VM;j++) {
            /// lungimea maxima a unui subsir care incepe cu i si se termina cu j
            int L = a[i][j];
            if (b[i][j] > L)
                L = b[i][j];
            for (int jj = i;jj<=j;jj++)
                if (a[i][jj] != 0)
                    for (int ii=jj;ii<=j;ii++)
                        if (b[ii][j] != 0) {
                            int aux = a[i][jj] + b[ii][j];
                            if (aux > L)
                                L = aux;
                        }
            r[i][j] = L;
        }
}

void init(int nod, int val) {
    for (int i=0;i<=VM;i++)
        for (int j=i;j<=VM;j++)
            a[nod][i][j] = 0;
    a[nod][ val ][ val ] = 1;
}

void copiere(int a[VM+1][VM+1], int b[VM+1][VM+1]) {
    for (int i=0;i<=VM;i++)
        for (int j=0;j<=VM;j++)
            a[i][j] = b[i][j];
}

void build(int nod, int st, int dr) {
    if (st == dr) {
        init(nod, v[st]);
    } else {
        int mid = (st + dr) / 2;
        build(2*nod, st, mid);
        build(2*nod+1, mid+1, dr);
        upd(a[nod], a[2*nod], a[2*nod+1]);
    }
}

void update(int nod, int st, int dr, int p, int x) {
    if (st == dr) {
        init(nod, x);
    } else {
        int mid = (st+dr)/2;
        if (p <= mid)
            update(2*nod, st, mid, p, x);
        else
            update(2*nod+1, mid+1, dr, p, x);
        upd(a[nod], a[2*nod], a[2*nod+1]);
    }
}

void query(int nod, int st, int dr, int A, int B) {
    if (A <= st && dr <= B) {
        if (first == 1) {
            copiere(sol, a[nod]);
            first = 0;
        } else {
            upd(saux, sol, a[nod]);
            copiere(sol, saux);
        }
    } else {
        int mid = (st + dr)/2;
        if (A <= mid)
            query(2*nod, st, mid, A, B);
        if (B >= mid+1)
            query(2*nod+1, mid+1, dr, A, B);
    }
}

void af(int a[VM+1][VM+1]) {
    for (int i=0;i<=VM;i++) {
        for (int j=0;j<=VM;j++)
            cout<<(a[i][j] == -INF ? 0 : a[i][j])<<" ";
        cout<<"\n";
    }
    cout<<"\n";
}

int main () {

    fin>>n;
    for (int i=1;i<=n;i++) {
        fin>>v[i];
        assert(0<=v[i] && v[i] <= 3);
    }
    build(1, 1, n);
    /// af(a[13]);
    fin>>m;
    for (;m--;) {
        fin>>op;
        if (op == 1) {
            fin>>p>>x;
            assert(1 <= p && p <= n);
            assert(0 <= x && x <= 3);
            update(1, 1, n, p, x);
        } else {
            fin>>A>>B;
            assert(1 <= A && A <= B && B <= n);
            first = 1;
            query(1, 1, n, A, B);
            int M = -INF;
            for (int i=0;i<=VM;i++)
                for (int j=i;j<=VM;j++)
                    if (sol[i][j] > M)
                        M = sol[i][j];
            fout<<M<<" ";
        }
    }
    return 0;
}
