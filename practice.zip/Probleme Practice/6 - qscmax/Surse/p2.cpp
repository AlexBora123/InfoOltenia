#include <fstream>
#define DIM 100010
using namespace std;
int L[DIM], v[DIM], n, m, i, p, x, a, b, t;
int scmax(int a, int b) {
    int m = 1, p, u;
    L[1] = a;
    for (int i=a+1;i<=b;i++) {
        p = 1; //caut pozitia ultimei valori L[poz] din L pentru care V[i] > V[ L[poz] ]
        u = m;
        while (p<=u) {
            int mid = p+(u-p)/2;
            if (v[ L[mid] ] > v[i])
                u = mid - 1;
            else
                p = mid + 1;
        }
        if (p > m) {
            m++;
            L[m] = i;
        } else
            if (v[ L[p] ] > v[i]) {
                L[p] = i;
            }
    }

    return m;
}


int main () {
    ifstream fin ("qscmax.in");
    ofstream fout("qscmax.out");
    fin>>n;
    for (i=1;i<=n;i++)
        fin>>v[i];
    fin>>m;
    for (i=1;i<=m;i++) {
        fin>>t;
        if (t == 1) {
            fin>>p>>x;
            v[p] = x;
        } else {
            fin>>a>>b;
            fout<<scmax(a, b)<<" ";
        }
    }

    return 0;
}
