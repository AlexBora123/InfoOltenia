
/// brut optimizat
#include <fstream>
#define DIM 100010
using namespace std;
int v[DIM], t[DIM];
int n, sol, i, maxim, p, m, j, M;
int main () {
    ifstream fin ("towers.in");
    ofstream fout("towers.out");
    fin>>n;
    for (i=1;i<=n;i++) {
        fin>>v[i];
        if (v[i] > M)
            M = v[i];
        t[i] = M;
    }
    fin>>m;
    for (i=1;i<=m;i++) {
        fin>>p;
        maxim = -1;
        sol = 0;
        for (j=p;j>=1;j--) {
            if (v[j] > maxim) {
                maxim = v[j];
                sol++;
            }
            if (maxim == t[p])
                break;
        }
        fout<<sol;
        if (i == m)
            fout<<"\n";
        else
            fout<<" ";
    }
    return 0;
}


