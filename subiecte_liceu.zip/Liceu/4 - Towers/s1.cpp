#include <fstream>
#define DIM 100001
using namespace std;
int st[DIM], sol[DIM];
int n, x, k, i, m;
int main () {
    ifstream fin ("towers.in");
    ofstream fout("towers.out");
    fin>>n;
    for (i=1;i<=n;i++) {
        fin>>x;
        while (k > 0 && x >= st[k])
            k--;
        st[++k] = x;
        sol[i] = k;

    }
    fin>>m;
    for (i=1;i<=m;i++) {
        fin>>x;
        fout<<sol[x];
        if (i == m)
            fout<<"\n";
        else
            fout<<" ";
    }
    return 0;
}


