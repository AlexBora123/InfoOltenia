#include <fstream>
#include <cassert>
#define DIM 100005
using namespace std;
int n, i, k, x, u;
int v[DIM], c[DIM], sol[DIM];
ifstream fin("towers.in");
ofstream fout("towers.out");
int main() {
    assert(fin>> n);
	assert(1 <= n && n <= 100000);
    for (i = 1; i <= n; i++) {
        assert(fin>> v[i]);
		assert(1 <= v[i] && v[i] < 1000000000);
        while (u > 0 && v[i] >= c[u]) {
            u--;
        }
        c[++u] = v[i];
        sol[i] = u;
    }
    assert(fin>> k);
	assert(1 <= k && k <= 100000);
    for (; k; k--) {
        assert(fin>> x);
		assert(1 <= x && x <= n);
        fout<< sol[x] <<" ";
    }
}

