#include <fstream>
#include <cassert>
#define DIM 100005
using namespace std;
int n, m, i, j, st, dr, mid, x, y;
long long sol;
int v[DIM], w[DIM];
int freq[1000005];
ifstream fin("pathinter.in");
ofstream fout("pathinter.out");
int comp(int jos1, int sus1, int jos2, int sus2) {
    int dif1 = sus1 - sus2;
    int dif2 = jos1 - jos2;
    if (dif1 * 1LL * dif2 < 0) {
        return 0;
    }
    if (dif1 < 0) {
        return -1;
    }
    return 1;
}
int comp(int i, int j) {
    int jos1 = v[i];
    int sus1 = v[i + 1];
    int jos2 = w[j];
    int sus2 = w[j + 1];
    if (i % 2 == 0) {
        swap(jos1, sus1);
    }
    if (j % 2 == 0) {
        swap(jos2, sus2);
    }
    return comp(jos1, sus1, jos2, sus2);
}
int main() {
    assert(fin>> n);
    assert(1 <= n && n <= 100000);
    for (i = 1; i <= n; i++) {
        assert(fin>> v[i]);
        assert(1 <= v[i] && v[i] <= 1000000);
        if (i > 2) {
            assert(v[i] > v[i - 2]);
        }
    }
    assert(fin>> m);
    assert(1 <= m && m <= 100000);
    for (i = 1; i <= m; i++) {
        assert(fin>> w[i]);
        assert(1 <= w[i] && w[i] <= 1000000);
        if (i > 2) {
            assert(w[i] > w[i - 2]);
        }
    }
    for (i = 1; i < n; i++) {
        st = 1;
        dr = m - 1;
        while (st <= dr) {
            mid = (st + dr) / 2;
            if (comp(i, mid) <= 0) {
                dr = mid - 1;
            } else {
                st = mid + 1;
            }
        }
        x = st;

        st = 1;
        dr = m - 1;
        while (st <= dr) {
            mid = (st + dr) / 2;
            if (comp(i, mid) >= 0) {
                st = mid + 1;
            } else {
                dr = mid - 1;
            }
        }
        y = dr;

        sol += y - x + 1;
    }

    for (i = 1; i <= n; i++) {
        freq[ v[i] ] = i % 2 + 1;
    }
    for (i = 1; i <= m; i++) {
        assert(freq[ w[i] ] != i % 2 + 1);
    }

    fout<< sol;
}

