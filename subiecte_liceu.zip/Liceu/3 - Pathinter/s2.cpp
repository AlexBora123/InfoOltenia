#include <iostream>
#include <fstream>

using namespace std;

const int DIM = 100010;
int n,m;
int v[DIM], w[DIM];

inline int intersection (int i, int jos1, int sus1, int j, int jos2, int sus2) {
    if (i % 2 == 0)
        swap (jos1, sus1);
    if (j % 2 == 0)
        swap (jos2, sus2);

    int dif_sus = sus1 - sus2;
    int dif_jos = jos1 - jos2;
    if (1LL* dif_sus * dif_jos < 0)
        return 0;
    if (dif_sus < 0)
        return -1;
    return 1;
}

int main() {
    ifstream cin ("pathinter.in");
    ofstream cout ("pathinter.out");

    cin>>n;
    for (int i = 1; i <= n; i++)
        cin>>v[i];

    cin>>m;
    for (int i = 1; i <= m; i++)
        cin>>w[i];

    long long sol = 0;
    for (int i = 1; i < n; i++) {
        int st = 1, dr = m-1, sol_st = 0;
        while (st <= dr) {
            int mid = (st + dr) >> 1;
            if (intersection(i, v[i], v[i+1], mid, w[mid], w[mid+1]) <= 0) {
                dr = mid-1;
            } else st = mid+1;
        }
        sol_st = st;

        st = 1, dr = m-1;
        int sol_dr = 0;
        while (st <= dr) {
            int mid = (st + dr) >> 1;
            if (intersection(i, v[i], v[i+1], mid, w[mid], w[mid+1]) >= 0) {
                st = mid+1;
                sol_dr = mid;
            } else dr = mid-1;
        }
        
        sol += sol_dr - sol_st + 1;
    }

    cout<<sol;

    return 0;
}

