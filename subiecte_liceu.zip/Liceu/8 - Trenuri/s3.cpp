#include <stdio.h>
#include <vector>
#include <unordered_map>
#include <cmath>
#include <cassert>

using namespace std;

#define MAX_N 100005
#define ERR 1e-6

int n;
vector< pair<int, int> > G[MAX_N];
int parent[MAX_N], dist_to_parent[MAX_N];
unordered_map<int, double> t1_path;

void dfs(int node, int current_parent, int current_dist_to_parent) {
  parent[node] = current_parent;
  dist_to_parent[node] = current_dist_to_parent;

  for (pair<int, int>& son : G[node]) {
    if (son.first != current_parent) {
      dfs(son.first, node, son.second);
    }
  }
}

int order(double a, double b) {
  if (abs(a - b) < ERR) return 0;
  if (a < b) {
    return -1;
  } else {
    return 1;
  }
}

void solve(int t1, int v1, int t2, int v2) {

  t1_path.clear();
  int dist = 0;

  while (t1 != 0) {
    t1_path[t1] = 1.0 * dist / v1;

    dist += dist_to_parent[t1];
    t1 = parent[t1];
  }

  dist = 0;

  while (t2 != 0) {

    double t2_to_node = 1.0 * dist / v2;

    if (t1_path.find(t2) != t1_path.end()) {

      int current_order = order(t1_path[t2], t2_to_node);

      if (current_order == 0) {
        printf("%d\n", 0);
        return;
      }

      double t2_to_parent = 1.0 * (dist + dist_to_parent[t2]) / v2;
      int order_to_parent = order(t1_path[parent[t2]], t2_to_parent);
      
      if (t2 != 1 && order_to_parent != current_order) {
        if (order_to_parent == 0) {
          printf("%d\n", 0);
        } else {
          printf("%d %d %d\n", 1, min(t2, parent[t2]), max(t2, parent[t2]));
        }
        return;
      }
    }

    dist += dist_to_parent[t2];
    t2 = parent[t2];
  }

  printf("%d\n", 0);
}

int main() {

  freopen("trenuri.in", "r", stdin);
  freopen("trenuri.out", "w", stdout);

  scanf("%d", &n);
  assert(1 <= n && n <= 100000);

  for (int i = 1; i < n; ++i) {
    int a, b, c;
    scanf("%d %d %d", &a, &b, &c);
    assert(1 <= a && a <= n);
    assert(1 <= b && b <= n);
    assert(a != b);
    assert(c > 0);

    G[a].push_back(make_pair(b, c));
    G[b].push_back(make_pair(a, c));
  }

  dfs(1, 0, 0);

  for (int i = 1; i <= n; ++i) {
    assert(i == 1 || dist_to_parent[i] > 0);
  }

  int m;
  scanf("%d", &m);

  while (m--) {
    int t1, v1, t2, v2;
    scanf("%d %d %d %d", &t1, &v1, &t2, &v2);
    assert(1 <= t1 && t1 <= n);
    assert(1 <= t2 && t2 <= n);
    assert(t1 != t2);
    assert(v1 > 0 && v2 > 0 && v1 != v2);

    solve(t1, v1, t2, v2);
  }

  return 0;
}

