#include <vector>
#include <cmath>
#include <cassert>
#include <fstream>

using namespace std;

const int MAXN = 100005;
const int LOG = 18;
const double EPS = 1e-6;

ifstream in("trenuri.in");
ofstream out("trenuri.out");

int numCities;
vector<pair<int, int>> adjacencyList[MAXN];
vector<int> distanceFromRoot(MAXN, 0), level(MAXN, 0);
vector<vector<int>> ancestors(LOG, vector<int>(MAXN, 0));

void depthFirstSearch(int node, int parent, int currentDistance) {
    level[node] = level[parent] + 1;
    distanceFromRoot[node] = currentDistance;

    ancestors[0][node] = parent;
    for (int p = 1; p < LOG; ++p) {
        ancestors[p][node] = ancestors[p - 1][ancestors[p - 1][node]];
    }

    for (auto& neighbor : adjacencyList[node]) {
        if (neighbor.first != parent) {
            depthFirstSearch(neighbor.first, node, currentDistance + neighbor.second);
        }
    }
}

int findLowestCommonAncestor(int city1, int city2) {
    if (level[city1] > level[city2]) swap(city1, city2);
    for (int p = LOG - 1; p >= 0; --p)
        if (level[ancestors[p][city2]] >= level[city1]) city2 = ancestors[p][city2];
    if (city1 == city2) return city1;
    for (int p = LOG - 1; p >= 0; --p)
        if (ancestors[p][city1] != ancestors[p][city2])
            city1 = ancestors[p][city1], city2 = ancestors[p][city2];
    return ancestors[0][city1];
}

int compareDoubles(double a, double b) {
    if (abs(a - b) < EPS) return 0;
    return (a < b) ? -1 : 1;
}

void processQuery(int city1, int speed1, int city2, int speed2) {
    int lca = findLowestCommonAncestor(city1, city2);
    
    auto computeTime = [](int city, int reference, int speed) {
        return static_cast<double>(distanceFromRoot[city] - distanceFromRoot[reference]) / speed;
    };
    
    double timeToLcaCity1 = computeTime(city1, lca, speed1);
    double timeToLcaCity2 = computeTime(city2, lca, speed2);
    double timeToRootCity1 = computeTime(city1, 0, speed1);
    double timeToRootCity2 = computeTime(city2, 0, speed2);
    
    int relativeOrderLca = compareDoubles(timeToLcaCity1, timeToLcaCity2);
    if (relativeOrderLca == 0 || relativeOrderLca == compareDoubles(timeToRootCity1, timeToRootCity2)) {
        out << "0\n";
        return;
    }
    
    int criticalNode = lca;
    for (int p = LOG-1; p >= 0; --p) {
        int nextNode = ancestors[p][criticalNode];
        if (nextNode == 0) continue;
        if (compareDoubles(computeTime(city1, nextNode, speed1), computeTime(city2, nextNode, speed2)) == relativeOrderLca) {
            criticalNode = nextNode;
        }
    }
    
    int parentCriticalNode = ancestors[0][criticalNode];
    assert(parentCriticalNode != 0);

    double timeToParentCriticalNode1 = computeTime(city1, parentCriticalNode, speed1);
    double timeToParentCriticalNode2 = computeTime(city2, parentCriticalNode, speed2);

    if (compareDoubles(timeToParentCriticalNode1, timeToParentCriticalNode2) == 0) {
        out << "0\n";
        return;
    }

    out << "1 " << min(criticalNode, parentCriticalNode) << " " << max(criticalNode, parentCriticalNode) << "\n";
}

int main(int argc, char* argv[]) {
    in >> numCities;
    assert(1 <= numCities && numCities <= 100000);
    
    for (int i = 1; i < numCities; ++i) {
        int cityA, cityB, distance;
        in >> cityA >> cityB >> distance;
        assert(1 <= cityA && cityA <= numCities);
        assert(1 <= cityB && cityB <= numCities);
        assert(cityA != cityB);
        assert(distance > 0);
        
        adjacencyList[cityA].emplace_back(cityB, distance);
        adjacencyList[cityB].emplace_back(cityA, distance);
    }
    
    depthFirstSearch(1, 0, 0);
    
    int numQueries;
    in >> numQueries;
    
    while (numQueries--) {
        int city1, speed1, city2, speed2;
        in >> city1 >> speed1 >> city2 >> speed2;
        assert(1 <= city1 && city1 <= numCities);
        assert(1 <= city2 && city2 <= numCities);
        assert(city1 != city2);
        assert(speed1 > 0 && speed2 > 0 && speed1 != speed2);
        
        processQuery(city1, speed1, city2, speed2);
    }
    
    return 0;
}