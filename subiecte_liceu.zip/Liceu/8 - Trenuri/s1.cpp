#include <stdio.h>
#include <vector>
#include <cmath>
#include <cassert>

using namespace std;

#define MAX_N 100005
#define LOG_MAX_N 18
#define ERR 1e-6

int n, logn;
vector< pair<int, int> > G[MAX_N];
int dist[MAX_N];
int level[MAX_N];
int ancestor[LOG_MAX_N][MAX_N];

void dfs(int node, int parent, int current_dist) {
  dist[node] = current_dist;
  level[node] = level[parent] + 1;

  ancestor[0][node] = parent;
  for (int p = 1; ancestor[p - 1][ancestor[p - 1][node]] != 0; ++p) {
    ancestor[p][node] = ancestor[p - 1][ancestor[p - 1][node]];
    logn = max(logn, p);
  }

  for (pair<int, int>& son : G[node]) {
    if (son.first != parent) {
      dfs(son.first, node, current_dist + son.second);
    }
  }
}

int find_lca(int t1, int t2) {

  if (level[t1] > level[t2]) {
    for (int p = logn; p >= 0; --p) {
      if (level[ancestor[p][t1]] >= level[t2]) {
        t1 = ancestor[p][t1];
      }
    }
  } else if (level[t2] > level[t1]) {
    for (int p = logn; p >= 0; --p) {
      if (level[ancestor[p][t2]] >= level[t1]) {
        t2 = ancestor[p][t2];
      }
    }
  }

  if (t1 == t2) return t1;

  for (int p = logn; p >= 0; --p) {
    if (ancestor[p][t1] != ancestor[p][t2]) {
      t1 = ancestor[p][t1];
      t2 = ancestor[p][t2];
    }
  }

  return ancestor[0][t1];
}

int order(double a, double b) {
  if (abs(a - b) < ERR) return 0;
  if (a < b) {
    return -1;
  } else {
    return 1;
  }
}

void solve(int t1, int v1, int t2, int v2) {

  int lca = find_lca(t1, t2);

  double t1_to_lca = 1.0 * (dist[t1] - dist[lca]) / v1;
  double t2_to_lca = 1.0 * (dist[t2] - dist[lca]) / v2;

  double t1_to_root = 1.0 * dist[t1] / v1;
  double t2_to_root = 1.0 * dist[t2] / v2;

  int order_to_lca = order(t1_to_lca, t2_to_lca);

  if (order_to_lca == 0 || order_to_lca == order(t1_to_root, t2_to_root)) {
    printf("%d\n", 0);
    return;
  }

  int a = lca;

  for (int p = logn; p >= 0; --p) {
    int b = ancestor[p][a];
    if (b == 0) continue;

    double t1_to_b = 1.0 * (dist[t1] - dist[b]) / v1;
    double t2_to_b = 1.0 * (dist[t2] - dist[b]) / v2;
    if (order(t1_to_b, t2_to_b) == order_to_lca) {
      a = b;
    }
  }

  int b = ancestor[0][a];
  assert(b != 0);

  double t1_to_b = 1.0 * (dist[t1] - dist[b]) / v1;
  double t2_to_b = 1.0 * (dist[t2] - dist[b]) / v2;
  int order_to_b = order(t1_to_b, t2_to_b);

  if (order_to_b == 0) {
    printf("%d\n", 0);
  } else {
    printf("%d %d %d\n", 1, min(a, b), max(a, b));
  }
}

int main(int argc, char* argv[]) {

  if (argc < 2) {
    freopen("trenuri.in", "r", stdin);
    freopen("trenuri.out", "w", stdout);
  } else {
    freopen(argv[1], "r", stdin);
    freopen(argv[2], "w", stdout);
  }

  scanf("%d", &n);
  assert(1 <= n && n <= 100000);

  for (int i = 1; i < n; ++i) {
    int a, b, c;
    scanf("%d %d %d", &a, &b, &c);
    assert(1 <= a && a <= n);
    assert(1 <= b && b <= n);
    assert(a != b);
    assert(c > 0);

    G[a].push_back(make_pair(b, c));
    G[b].push_back(make_pair(a, c));
  }

  dfs(1, 0, 0);

  for (int i = 1; i <= n; ++i) {
    assert(i == 1 || dist[i] > 0);
  }

  int m;
  scanf("%d", &m);

  while (m--) {
    int t1, v1, t2, v2;
    scanf("%d %d %d %d", &t1, &v1, &t2, &v2);
    assert(1 <= t1 && t1 <= n);
    assert(1 <= t2 && t2 <= n);
    assert(t1 != t2);
    assert(v1 > 0 && v2 > 0 && v1 != v2);

    solve(t1, v1, t2, v2);
  }

  return 0;
}


