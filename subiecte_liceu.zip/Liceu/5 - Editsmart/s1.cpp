#include <fstream>
#include <queue>
#include <cassert>

using namespace std;

const int DIM = 1001;

int n, x_start, y_start, x_end, y_end;
char grid[DIM][DIM];
int Left[DIM][DIM], Right[DIM][DIM], dist[DIM][DIM];
int di[] = {-1,1,0,0};
int dj[] = {0,0,-1,1};
queue<pair<int,int> > q;

inline int inmat (int i, int j) {
    return i >= 1 && i <= n && j >= 1 && j <= n;
}
int main() {

    ifstream cin ("editsmart.in");
    ofstream cout ("editsmart.out");

    cin>>n;
    assert(n <= 1000);

    cin.get();
    for (int i = 1; i <= n; i++) {
        cin.getline(grid[i]+1,DIM);
        for (int j = 1; j <= n; j++) {
            assert( (grid[i][j] >= 'a' && grid[i][j] <= 'z') || grid[i][j] == ' ');
            assert (!(grid[i][j] == ' ' && grid[i][j-1] == ' '));
        }
        assert(grid[i][1] >= 'a' && grid[i][1] <= 'z');
        assert(grid[i][n] >= 'a' && grid[i][n] <= 'z');
    }
    cin>>x_start>>y_start>>x_end>>y_end;

    assert(x_start >= 1 && x_start <= n);
    assert(x_end >= 1 && x_end <= n);
    assert(y_start >= 1 && y_start <= n);
    assert(y_end >= 1 && y_end <= n);

    // left[i][j] - coloana primului inceput de cuvant din stanga pozitiei i,j
    // right[i][j] - coloana primului inceput de cuvant din dreapta pozitiei i,j,
    //                  sau -1 daca nu exista alt inceput de cuvant in dreapta
    for (int i = 1; i <= n; i++) {
        Left[i][1] = 1;
        for (int j = 2; j <= n; j++) {
            Left[i][j] = (grid[i][j-2] == ' ') ? j-1 : Left[i][j-1];
        }

        int j = n;
        while (j >= 1 && grid[i][j] >= 'a' && grid[i][j] <= 'z') {
            Right[i][j] = -1;
            j--;
        }

        for (; j >= 1; j--) {
            Right[i][j] = (grid[i][j] == ' ') ? j+1 : Right[i][j+1];
        }
    }

    dist[x_start][y_start] = 1;
    q.push(make_pair(x_start, y_start));
    while (!q.empty()) {
        int ic = q.front().first;
        int jc = q.front().second;
        q.pop();
        if (ic == x_end && jc == y_end) {
            cout<<dist[ic][jc] - 1;
            return 0;
        }
        // sageti
        for (int dir = 0; dir < 4; dir++) {
            int iv = ic + di[dir];
            int jv = jc + dj[dir];
            if (inmat(iv,jv) && !dist[iv][jv]) {
                dist[iv][jv] = 1 + dist[ic][jc];
                q.push(make_pair(iv,jv));
            }
        }

        // ctrl_left
        int new_j = Left[ic][jc];
        if (!dist[ic][new_j]) {
            dist[ic][new_j] = 1 + dist[ic][jc];
            q.push(make_pair(ic,new_j));
        }
        // ctrl_right
        new_j = Right[ic][jc];
        if (new_j != -1 && !dist[ic][new_j]) {
            dist[ic][new_j] = 1 + dist[ic][jc];
            q.push(make_pair(ic,new_j));
        }

        // home
        if (!dist[ic][1]) {
            dist[ic][1] = 1 + dist[ic][jc];
            q.push(make_pair(ic,1));
        }
        // end
        if (!dist[ic][n]) {
            dist[ic][n] = 1 + dist[ic][jc];
            q.push(make_pair(ic,n));
        }
    }

    cin.close();
    cout.close();
    return 0;
}

