#include <fstream>
#include <vector>
#include <string>
#include <cassert>
#include <deque>
using namespace std;

ifstream in("editsmart.in");
ofstream out("editsmart.out");

const int DIM = 1005;
const int INF = 1e9;

int N;

const int dx[4] = {-1, 0, 1, 0};
const int dy[4] = {0, 1, 0, -1};

char matrix[DIM][DIM];
int dst[DIM][DIM];
deque<pair<int, int>> que;
pair<int, int> prv[DIM][DIM], nxt[DIM][DIM];

vector<pair<int, int>> calculateNeighbors(pair<int, int> u) {
  vector<pair<int, int>> neighbors;

  for (int d = 0; d < 4; ++d) {
    int x = u.first + dx[d];
    int y = u.second + dy[d];

    if (x < 1 || x > N || y < 1 || y > N) continue;

    neighbors.push_back({x, y});
  }

  neighbors.push_back(prv[u.first][u.second]);
  neighbors.push_back(nxt[u.first][u.second]);
  neighbors.push_back({u.first, 1});
  neighbors.push_back({u.first, N});

  return neighbors;
}

int main() {
  in >> N;
  assert(1 <= N && N <= 1000);
  in.ignore(); 

  for (int i = 1; i <= N; ++i) {
    string line;
    getline(in, line);
    copy(line.begin(), line.end(), matrix[i] + 1);

    int p = 1;
    for (int j = 1; j <= N; ++j) {
      prv[i][j] = {i, p};

      if (matrix[i][j-1] == ' ' && matrix[i][j] != ' ') {
        p = j;
      }
    }

    p = N;
    for (int j = N-1; j >= 1; --j) {
      nxt[i][j] = {i, p};

      if (matrix[i][j-1] == ' ' && matrix[i][j] != ' ') {
        p = j;
      }
    }
  }
  
  pair<int, int> start, end;
  in >> start.first >> start.second >> end.first >> end.second; 
  assert(1 <= start.first && start.first <= N);
  assert(1 <= start.second && start.second <= N);
  assert(1 <= end.first && end.first <= N);
  assert(1 <= end.second && end.second <= N);

  for (int i = 1; i <= N; ++i) {
    for (int j = 1; j <= N; ++j) {
      dst[i][j] = INF;
    }
  }

  dst[start.first][start.second] = 0;
  que.push_back(start);

  while (que.size() && dst[end.first][end.second] == INF) {
    pair<int, int> u = que.front();
    que.pop_front();

    for (auto v : calculateNeighbors(u)) {
      if (dst[v.first][v.second] == INF) {
        dst[v.first][v.second] = dst[u.first][u.second] + 1;

        if (v.first == end.first && v.second == end.second) {
          break;
        }
        que.push_back(v);
      }
    }
  }

  out << dst[end.first][end.second] << '\n';

  return 0;
}

