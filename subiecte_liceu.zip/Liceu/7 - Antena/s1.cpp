#include <bits/stdc++.h>
using namespace std;

ifstream fin("antena.in");
ofstream fout("antena.out");

const int DIM = 1000005;
const int MOD = 1e9 + 7;
int n, nv, nr_vec[DIM], dp[DIM], nvec_total, ans;

int main() {
    fin >> n;
    assert(n >= 1 && n <= 1000000);

    for (int i = 1; i <= n; i++) {
        fin >> nr_vec[i];
        assert(nr_vec[i] >= 0 && nr_vec[i] <= 2);
        
        nvec_total += nr_vec[i];

        for (int j = 1; j <= nr_vec[i]; j++) {
            int x; fin >> x;
            assert(x >= n);
        }
    }

    dp[1] = (1<<nr_vec[1]);
    for (int i = 2; i <= n; i++)
        dp[i] = 1LL * (1<<nr_vec[i]) * (dp[i-1] + 1) % MOD;

    ans = nvec_total % MOD;
    for (int i = 1; i <= n; i++)
        ans = (ans + dp[i]) % MOD;

    fout << ans << '\n';
    return 0;
}