#include <bits/stdc++.h>
using namespace std;

ifstream fin("antena.in");
ofstream fout("antena.out");

const int DIM = 1000005;
const int MOD = 1e9 + 7;
int n, nv, nr_vec[DIM], dp[DIM], nvec_total, ans;

int main() {
    fin >> n;
    assert(n >= 1 && n <= 1000000);

    for (int i = 1; i <= n; i++) {
        fin >> nr_vec[i];
        assert(nr_vec[i] == 0);
    }
    
    ans = 1LL * n * (n + 1) / 2 % MOD;
    fout << ans << '\n';
    return 0;
}