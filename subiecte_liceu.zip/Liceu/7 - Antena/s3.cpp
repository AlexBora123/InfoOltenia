#include <bits/stdc++.h>
using namespace std;

ifstream fin("antena.in");
ofstream fout("antena.out");

const int DIM = 1000005;
const int MOD = 1e9 + 7;
int n, nv, nr_vec[DIM], nvec_total, ans;

int lg_putere(int x, int y) {
    int sol = 1;
    while (y) {
        if (y & 1) {
            sol = 1LL * sol * x % MOD;
        }
        x = 1LL * x * x % MOD;
        y >>= 1;
    }

    return sol;
}

int main() {
    fin >> n;
    assert(n >= 1 && n <= 1000000);

    for (int i = 1; i <= n; i++) {
        fin >> nr_vec[i];
        assert(nr_vec[i] >= 0 && nr_vec[i] <= 2);
        
        nvec_total += nr_vec[i];

        for (int j = 1; j <= nr_vec[i]; j++) {
            int x; fin >> x;
            assert(x >= n);
        }
    }

    ans = nvec_total % MOD;
    for (int i = 1; i <= n; i++) {
        for (int j = i; j <= n; j++) {
            int e = 0;
            for (int k = i; k <= j; k++) {
                e += nr_vec[k];
            }

            ans = (ans + lg_putere(2, e)) % MOD;
        }
    }

    fout << ans << '\n';
    return 0;
}