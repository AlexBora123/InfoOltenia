#include <cstdio>
#define NMAX 1003

using namespace std;

int n,cerinta;
FILE *fin,*fout;
int v[NMAX],ocupate;

int main() {

    fin=fopen("drag.in","r");
    fout=fopen("drag.out","w");

    fscanf(fin,"%d %d",&cerinta,&n);
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
        {
            int x;
            fscanf(fin,"%d",&x);
            ocupate+=x;
            v[n-i+1]+=x;
        }
    }
    if(cerinta == 1)
    {
        fprintf(fout,"%d",ocupate/n);
        return 0;
    }

    int st=1,dr=2,pasi=0;
    while (st <= ocupate / n)
    {
        while (v[st] < n)
        {
            while(v[dr]==0 && dr<n)
            {
                dr++;
            }
            // printf("%d %d %d %d\n",v[st],v[dr],st,dr);
            pasi+=dr-st;
            v[st]++;
            v[dr]--;
        }
        st++;
        if(st == dr){
            dr++;
        }
    }
    fprintf(fout,"%d %d\n",ocupate / n, pasi);
    return 0;
}


