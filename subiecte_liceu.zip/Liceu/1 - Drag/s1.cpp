#include <fstream>
#include <cassert>
#define DIM 1010

using namespace std;

long long s[DIM], a[DIM*DIM], b[DIM*DIM];
long long n, c, i, j, x, nrUnu, liniiComplete, rest, numarZerouriJos, sol, k;

int main () {
    ifstream fin ("drag.in");
    ofstream fout("drag.out");
    fin>>c>>n;
    assert(1 <= n && n <= 1000);
    assert(1 <= c && c <= 1000);
    for (i=1;i<=n;i++) {
        for (j=1;j<=n;j++) {
            fin>>x;
            assert(0 <= x && x <= 1);
            s[i] += x;
        }
        nrUnu += s[i];
    }
    liniiComplete = nrUnu / n;
    rest = nrUnu % n;

    fout<<liniiComplete;
    if (c == 1) {
        fout<<"\n";
        return 0;
    }

    for (i=n;i>=n-liniiComplete+1;i--) {
        numarZerouriJos+=n-s[i];
        for (j=1;j<=n-s[i];j++) {
            a[++k] = i;
        }
    }
    k = 0;
    for (i=n-liniiComplete;i>=1 && k < numarZerouriJos;i--) {
        for (j=1;j<=s[i];j++) {
            b[++k] = i;
            if (k >= numarZerouriJos)
                break;
        }
    }

    for (i=1;i<=numarZerouriJos;i++)
        sol+=a[i]-b[i];
    fout<<" "<<sol<<"\n";

    return 0;
}


