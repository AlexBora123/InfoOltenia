#include <fstream>
#include <cmath>
#include <vector>
#include <algorithm>

using namespace std;

ifstream fin("drag.in"); 
ofstream fout("drag.out"); 

vector<int> linii_ocupate;
vector<int> linii_libere;


int main () {
    int n, c;
    fin >> c >> n;
    int ocupate = 0;

    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            int x;
            fin >> x;
            ocupate += x;
            if (x) {
                linii_ocupate.push_back(i);
            } else {
                linii_libere.push_back(i);
            }
        }
    }

    if (c == 1) {
        fout << ocupate / n;
        return 0; 
    }

    int solutie = 0;

    sort(linii_libere.begin(), linii_libere.end(), greater<int>());
    sort(linii_ocupate.begin(), linii_ocupate.end(), greater<int>());

    for (int i = 0, j = 0; i < linii_ocupate.size() && j < linii_libere.size();) {
        int ocupat = linii_ocupate[i];
        int liber = linii_libere[j];

        // daca ocupat este mai jos decat liniile complete nu trebuie mutat
        if (ocupat >= n - (ocupate / n)) {
            ++i;
            continue;
        }

        // daca liber e mai sus decat liniile care se vor ocupa am terminat procesarea
        if (liber < n - (ocupate / n)) 
            break;
        
        solutie += liber - ocupat;
        ++i;
        ++j;
    }

    fout << ocupate / n << " " << solutie;

    return 0;
}

