/*
* Author: Bogdan Iordache
* Time Complexity: O(N)
*/
#include <fstream>
#include <iostream>
#include <vector>
#include <cassert>
using namespace std;

int solve(int left, int right, vector<int>& sol, int delta, const vector<int>& best) {
  if (left > right) {
    return 0;
  }
  if (left == right) {
    sol[left] = 1 + delta;
    return 0;
  }

  int start = best[right - left + 1];
  sol[left] = start + delta;
  return right - left
    + solve(left + 1, left + start - 1, sol, delta, best)
    + solve(left + start, right, sol, start + delta, best);
}

int main() {
  #ifndef LOCAL
  ifstream cin("quick.in");
  ofstream cout("quick.out");
  #endif

  int p, n;
  cin >> p >> n;
  assert(1 <= p && p <= 2);
  assert(1 <= n && n <= 100000);

  vector<int> best;
  best.reserve(n + 1);
  best.push_back(0);
  best.push_back(1);
  best.push_back(1);

  int curr = 3;
  while (curr <= n) {
    if (curr + 1 == ((curr + 1) & (-curr - 1))) { // power of 2
      int cnt = (curr + 1) / 2 + 1;
      for (int i = 0; i < cnt; ++i)
        if ((int)best.size() <= n)
          best.push_back((curr + 1) / 2);
      curr += cnt;
    } else {
      best.push_back(best.back() + 1);
      curr++;
    }
  }

  vector<int> sol(n + 1);
  int num_op = solve(1, n, sol, 0, best);

  if (p == 1) {
    cout << num_op << "\n";
  } else {
    for (int i = 1; i <= n; ++i) {
      cout << sol[i] << " \n"[i == n];
    }
  }


  return 0;
}

