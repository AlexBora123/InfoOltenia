#include <fstream>
#include <cassert>
#define DIM 100005
using namespace std;
int p, n, i, j, val;
int d[DIM], v[DIM];
ifstream fin("quick.in");
ofstream fout("quick.out");
void afis(int n, int val) {
    if (n == 0) {
        return;
    }
    fout<< v[n] + val <<" ";
    afis(v[n] - 1, val);
    afis(n - v[n], val + v[n]);
}
int main() {
    assert(fin>> p >> n);
    assert(p == 1 || p == 2);
    assert(1 <= n && n <= 100000);
    v[1] = 1;
    for (i = 2; i <= n; i++) {
        d[i] = 1000000000;
        for (j = 1; j <= i; j++) {
            val = i - 1 + d[j - 1] + d[i - j];
            if (val < d[i]) {
                d[i] = val;
                v[i] = j;
            }
        }
    }
    if (p == 1) {
        fout<< d[n] <<"\n";
    }
    else {
        afis(n, 0);
    }
}

