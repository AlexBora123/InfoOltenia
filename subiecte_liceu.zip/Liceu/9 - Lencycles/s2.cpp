#include <fstream>
#include <cassert>
#define DIM 100005
#define mod 1000000007
using namespace std;
int n, k, i, x, sol, sum;
int fact[DIM], fr[DIM];
ifstream fin("lencycles.in");
ofstream fout("lencycles.out");
int mult(int x, int e) {
    if (e == 0) {
        return 1;
    }
    else {
        int a = mult(x, e / 2);
        if (e % 2 == 0) {
            return a * 1LL * a % mod;
        }
        else {
            return a * 1LL * a % mod * x % mod;
        }
    }
}
int comb(int n, int k) {
    return fact[n] * 1LL * mult(fact[k], mod - 2) % mod * mult(fact[n - k], mod - 2) % mod;
}
int main() {
    assert(fin>> n >> k);
    assert(1 <= n && n <= 100000);
    fact[0] = 1;
    for (i = 1; i <= n; i++) {
        fact[i] = fact[i - 1] * 1LL * i % mod;
    }
    sol = 1;
    for (; k; k--) {
        assert(fin>> x);
        sum += x;
        sol = sol * 1LL * fact[x - 1] % mod * comb(n, x) % mod;
        n -= x;
        fr[x]++;
    }
    assert(n == 0);
    for (i = 1; i <= sum; i++) {
        if (fr[i] > 1) {
            sol = sol * 1LL * mult(fact[ fr[i] ], mod - 2) % mod;
        }
    }
    fout<< sol;
}

