//
// Created by Adrian-Emanuel Dicu on 16.01.2025.
//
#include <fstream>
using namespace std;

ifstream in("lencycles.in");
ofstream out("lencycles.out");

const int DIM = 1e5 + 5;
const int MOD = 1e9 + 7;

int fact[DIM];
int countLens[DIM];

int logPow(int x, int n) {
  if (!n)
    return 1;
  int y = logPow(x, n/2);
  y = 1LL * y * y % MOD;
  if (n % 2)
    y = 1LL * y * x % MOD;
  return y;
}

int comb(int n, int k) {
  return 1LL * fact[n] * logPow(fact[k], MOD-2) % MOD * logPow(fact[n-k], MOD-2) % MOD;
}

int main() {
  int n, k;
  in >> n >> k;

  fact[0] = 1;
  for (int i = 1; i <= n; ++i)
    fact[i] = 1LL * fact[i-1] * i % MOD;

  int answer = 1;
  for (int i = 1, v = n; i <= k; ++i) {
    int x;
    in >> x;

    answer = 1LL * answer * comb(v, x) % MOD;
    answer = 1LL * answer * fact[x-1] % MOD;
    v -= x;
    ++countLens[x];
  }

  for (int i = 1; i <= n; ++i)
    if (countLens[i])
      answer = 1LL * answer * logPow(fact[countLens[i]], MOD-2) % MOD;

  out << answer << endl;

  return 0;
}


