#include <fstream>
#include <algorithm>
#include <cassert>
#define DIM 1001
using namespace std;
long long a[DIM][DIM], v[DIM*DIM];
int f[1001], P[1001];
int n, k, i, j, sol, p, m, t, L1, C1, L2, C2;
int main () {
    ifstream fin ("color.in");
    ofstream fout("color.out");
    fin>>n>>k;
    assert(1 <= n && n <= 1000);
    assert(1 <= k && k <= 150);

    for (i=2;i<=1000;i++)
        if (f[i] == 0) {
            P[++p] = i;
            for (j=i+i;j<=1000;j+=i)
                f[j] = 1;
        }

    for (i=1;i<=n;i++)
        for (j=1;j<=n;j++)
            a[i][j] = 1;

    p = 0;
    for (t=1;t<=k;t++) {
        fin>>L1>>C1>>L2>>C2;
        assert(1 <= L1 && L1 <= L2 && L2 <= n);
        assert(1 <= C1 && C1 <= C2 && C2 <= n);
        p++;
        for (i=L1;i<=L2;i++)
            for (j=C1;j<=C2;j++)
                a[i][j] *= P[p];
    }

    for (i=1;i<=n;i++)
        for (j=1;j<=n;j++)
            v[++m] = a[i][j];
    sort(v+1, v+m+1);
    if (v[1] == 1)
        sol = 0;
    else
        sol = 1;
    for (i=2;i<=m;i++)
        if (v[i]!=v[i-1])
            sol++;
    fout<<sol<<"\n";

    /**
    for (i=1;i<=n;i++) {
        for (j=1;j<=n;j++)
            fout<<a[i][j]<<" ";
        fout<<"\n";
    }
    **/
    return 0;
}


