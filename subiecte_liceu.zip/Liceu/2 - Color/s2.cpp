#include <fstream>
#include <iostream>
#include <algorithm>
#include <cassert>
#include <bitset>
#define DIM 1001
using namespace std;
bitset<151> a[DIM][DIM], v[DIM*DIM];
int f[1001], P[1001];
int n, k, i, j, sol, p, m, t, L1, C1, L2, C2;


bool cmp(const bitset<151> &a, const bitset<151> &b) {
    int i;
    for (i=0;i<=140;i++)
        if (a[i] != b[i])
            break;
    if (i > 150)
        return false;
    return a[i]<b[i];
}


void write(bitset<151> a, int L) {
    for (int i=0;i<=L;i++)
        cout<<a[i];
    cout<<" ";
}

int main () {
    ifstream fin ("color.in");
    ofstream fout("color.out");
    fin>>n>>k;
    assert(1 <= n && n <= 1000);
    assert(1 <= k && k <= 150);

    p = 0;
    for (t=1;t<=k;t++) {
        fin>>L1>>C1>>L2>>C2;
        assert(1 <= L1 && L1 <= L2 && L2 <= n);
        assert(1 <= C1 && C1 <= C2 && C2 <= n);
        p++;
        for (i=L1;i<=L2;i++)
            for (j=C1;j<=C2;j++)
                a[i][j][p] = 1;
    }

    for (i=1;i<=n;i++)
        for (j=1;j<=n;j++)
            if (a[i][j].count() != 0)
                v[++m] = a[i][j];
    sort(v+1, v+m+1, cmp);

    sol = 1;
    for (i=2;i<=m;i++)
        if (v[i]!=v[i-1])
            sol++;
    fout<<sol<<"\n";
/**
    for (i=1;i<=n;i++) {
        for (j=1;j<=n;j++)
            write(a[i][j], 6);
        cout<<"\n";
    }

    for (i=1;i<=m;i++)
        write(v[i], 6);
**/
    return 0;
}


