#include <fstream>
using namespace std;
ifstream f("ciulini.in");
ofstream g("ciulini.out");
int n,i,c,k,mij,st,dr;
int main()
{
    f>>c;
    f>>n;
    if(n%2==0)
        mij=n/2;
    else
        mij=n/2+1;
    if(c==1)
    {
        st=mij;
        dr=mij+1;
        for(i=1; i<=n/2; i++)
        {
            g<<st<<" "<<dr<<" ";
            st--;
            dr++;
        }
        if(n%2!=0)
            g<<st;
    }
    else
    {
        f>>k;
        if(k>mij)
            g<<(k-mij)*2;
        else
            g<<(mij-k)*2+1;
    }
    return 0;
}
