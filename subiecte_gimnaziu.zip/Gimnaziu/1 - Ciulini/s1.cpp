#include <fstream>
#include <cassert>
using namespace std;

int c, n, k, start, nextSt, nextDr, c2;

int main () {
    ifstream fin ("ciulini.in");
    ofstream fout("ciulini.out");

    fin>>c>>n;
    assert(1 <= c && c <= 2);
    assert(1 <= n && n <= 1000000000);

    if (n % 2 == 1) {
        start = n/2+1;
    } else {
        start = n/2;
    }


    if (c == 2) {
        fin>>k;
        assert(1 <= k && k <= n);
        if (k == start) {
            fout<<"1\n";
            return 0;
        }

        if (k > start) {
            fout<<2*(k-start-1)+2;
        } else {
            fout<<2*(start-k-1)+3;
        }
        return 0;

    }



    nextDr = start+1;
    nextSt = start-1;
    if (c == 1)
        fout<<start<<" ";
    if (start == k)
        c2 = 1;
    for (int i=2;i<=n;i++) {
        if (i%2 == 0) {
            if (c == 1)
                fout<<nextDr<<" ";
            if (nextDr == k)
                c2 = i;
            nextDr++;
        } else {
            if (c == 1)
                fout<<nextSt<<" ";
            if (nextSt == k)
                c2 = i;
            nextSt--;
        }
    }

    return 0;
}


