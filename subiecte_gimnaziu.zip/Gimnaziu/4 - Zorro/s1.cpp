#include <fstream>
#include <cassert>
#define DIM 2010
#define INF 1000000000
using namespace std;

int a[DIM][DIM], D[DIM][DIM], ssl[DIM][DIM], ssr[DIM][DIM];
int n, m, i, j, sol = -INF;

int maxim(int a, int b) {
    if (a>b)
        return a;
    else
        return b;
}

int main () {
    ifstream fin ("zorro.in");
    ofstream fout("zorro.out");

    fin>>n>>m;
    assert(2 <= n && n <= 1000);
    assert(2 <= m && m <= 1000);
    for (i=1;i<=n;i++) {
        for (j=1;j<=m;j++) {
            assert(fin>>a[i][j]);
            assert(a[i][j] >= -1000 && a[i][j] <= 1000);
        }
        ssl[i][1] = a[i][1];
        for (j=2;j<=m;j++)
            ssl[i][j] = maxim(ssl[i][j-1] + a[i][j], a[i][j]);
        ssr[i][m] = a[i][m];
        for (j=m-1;j>=1;j--)
            ssr[i][j] = maxim(ssr[i][j+1] + a[i][j], a[i][j]);
    }
    int x;
    assert(!(fin>>x));

    for (i=1;i<=n;i++)
        for (j=1;j<=m;j++) {
            if (i == 1)
                D[i][j] = ssl[i][j-1] + a[i][j];
            else {
                if (D[i-1][j+1] + a[i][j] > ssl[i][j-1] + a[i][j]) {
                    D[i][j] = D[i-1][j+1] + a[i][j];
                    if (j!=m)
                        sol = maxim(sol, D[i][j] + ssr[i][j+1]);
                }
                else {
                    if (j!=m)
                        sol = maxim(sol, a[i][j] + a[i-1][j+1] +
                                    ssl[i-1][j] + ssr[i][j+1]);
                    D[i][j] = ssl[i][j-1] + a[i][j];
                }
            }
        }
/**
    for (i=1;i<=n;i++) {
        for (j=1;j<=m;j++)
            fout<<D[i][j]<<" ";
        fout<<"\n";
    }
**/
    fout<<sol<<"\n";
    return 0;
}


