#include <iostream>
#include <fstream>
#define inf 2e9
using namespace std;
int a[1003][1003],n,m,Max,l,c;
int d[1003][1003][3];
ifstream fin("zorro.in");
ofstream fout("zorro.out");
int main()
{
   fin>>n>>m;
   for(int i=1;i<=n;i++)
    for(int j=1;j<=m;j++){
        fin>>a[i][j];
        d[i][j][0]=d[i][j][1]=d[i][j][2]=-inf;
   }
   for(int i=0;i<=m+1;i++)
   {
       d[0][i][0]=d[n+1][i][0]=d[0][i][1]=d[n+1][i][1]=d[0][i][2]=d[n+1][i][2]=-inf;
   }
   for(int i=0;i<=n+1;i++)
   {
       d[i][0][0]=d[i][m+1][0]=d[i][0][1]=d[i][m+1][1]=d[i][0][2]=d[i][m+1][2]=-inf;
   }
   Max=-inf;
   for(int i=1;i<=n;i++)
      for(int j=1;j<=m;j++){
          d[i][j][0]=a[i][j];
          if(d[i][j-1][0]+a[i][j]>a[i][j])
              d[i][j][0]=d[i][j-1][0]+a[i][j];
          if(j+1<=m&&d[i-1][j+1][1]!=-inf)
                 d[i][j][1]=a[i][j]+d[i-1][j+1][1];
          if(j+1<=m&&d[i-1][j][0]+a[i-1][j+1]+a[i][j]>d[i][j][1])
                 d[i][j][1]=d[i-1][j][0]+a[i-1][j+1]+a[i][j];
          if(d[i][j-1][1]!=-inf)
                d[i][j][2]=d[i][j-1][1]+a[i][j];
          if(d[i][j-1][2]!=-inf)
              if(d[i][j-1][2]+a[i][j]>d[i][j][2])
                 d[i][j][2]=d[i][j-1][2]+a[i][j];
            if(d[i][j][2]!=-inf&&d[i][j][2]>Max){
                Max=d[i][j][2];
                l=i;c=j;
            }
      }
   fout<<Max;
    return 0;
}


