#include <fstream>
#define DIM 1010
#define INF 1000000000
using namespace std;
int a[DIM][DIM], ssl[DIM][DIM], ssr[DIM][DIM], SD[DIM][DIM];
int n, m, i, j, aux, sol, ii, jj;

ifstream fin ("zorro.in");
ofstream fout("zorro.out");

int maxim(int a, int b) {
    if (a > b)
        return a;
    else
        return b;
}

void af(int a[DIM][DIM]) {
    for (int i=1;i<=n;i++) {
        for (int j=1;j<=m;j++)
            fout<<a[i][j]<<" ";
        fout<<"\n";
    }
    fout<<"\n";
}

int main () {

    sol = -INF;
    fin>>n>>m;
    for (i=1;i<=n;i++) {
        for (j=1;j<=m;j++) {
            fin>>a[i][j];
            if (j==1)
                ssl[i][j] = a[i][j];
            else
                ssl[i][j] = maxim(ssl[i][j-1] + a[i][j], a[i][j]);
        }
        ssr[i][m] = a[i][m];
        SD[i][m] = a[i][m];
        for (j=m-1;j>=1;j--) {
            ssr[i][j] = maxim(a[i][j], ssr[i][j+1]+a[i][j]);
            SD[i][j] = SD[i-1][j+1] + a[i][j];
        }
    }

    for (i=1;i<n;i++)
        for (ii=i+1;ii<=n;ii++) {
            for (j=2;j<=m;j++) {
                jj = j+i-ii;
                if (jj >= 1) {
                    aux = SD[ii][jj] - SD[i-1][j+1] + ssl[i][j-1] + ssr[ii][jj+1];
                    if (aux > sol)
                        sol = aux;
                }
            }
        }
///    af(a);
///    af(ssl);
///    af(ssr);
///    af(SD);

    fout<<sol;
    return 0;
}


