// n^3
#include <fstream>
#define DIM 2010
using namespace std;

int a[DIM], b[DIM], c[DIM], A[DIM];
int T, n, m, i, L, p, I;

int main () {
    ifstream fin ("prieteni.in");
    ofstream fout("prieteni.out");
    for (fin>>T;T--;) {
        fin>>n;
        for (i=1;i<=n;i++) {
            fin>>a[i];
            A[i] = a[i];
        }
        fin>>m;
        for (i=1;i<=m;i++)
            fin>>b[i];

        L = n-m;
        int ok = 0;
        for (I=1;I+L-1<=m && !ok;I++)
            for (p=2;p+L-1<n;p++) {
                for (i=1;i<=n;i++) {
                    A[i] = a[i];
                }
                /// iau secventa de lungime L care incepe in a la pozitia p
                for (i=1;i<=L;i++)
                    c[i] = a[p+i-1];
                /// sterg secventa de lungime L care incepe in a la pozitia p
                for (i=p+L;i<=n;i++)
                    A[i-L] = A[i];
                /// acum A are m elemente
                /// aplic pe c peste A la pozitia I
                for (i=1;i<=L;i++)
                    A[I+i-1] += c[i];
                /// verific daca A si b sunt identice
                int id = 1;
                for (i=1;i<=m;i++)
                    if (A[i] != b[i]) {
                        id = 0;
                        break;
                    }
                if (id) {
                    ok = 1;
                    break;
                }
            }
        if (!ok)
            fout<<"0\n";
        else
            fout<<"1 "<<p<<" "<<L<<" "<<I-1<<"\n";
    }

    return 0;
}


