/// n^3 L=1
#include <fstream>
#define DIM 2010
using namespace std;

int a[DIM], b[DIM], c[DIM], A[DIM];
int T, n, m, i, L, p, I;

int main () {
    ifstream fin ("prieteni.in");
    ofstream fout("prieteni.out");
    for (fin>>T;T--;) {
        fin>>n;
        for (i=1;i<=n;i++) {
            fin>>a[i];
        }
        fin>>m;
        for (i=1;i<=m;i++)
            fin>>b[i];
        int ok = 0;
        for (p=2;p<n && !ok;p++)
            for (I=1;I<=n;I++) {
                for (i=1;i<=n;i++)
                    A[i] = a[i];
                int aux = a[p];
                /// sterg elementul de pe pozitia p din A
                for (i=p;i<n;i++)
                    A[i] = A[i+1];
                A[I] += aux;
                int id = 1;
                for (i = 1;i<=n-1;i++)
                    if (A[i] != b[i]) {
                        id = 0;
                        break;
                    }
                if (id) {
                    ok = 1;
                    break;
                }
            }
        if (!ok)
            fout<<"0\n";
        else
            fout<<"1 "<<p-1<<" "<<1<<" "<<I<<"\n";
    }
    return 0;
}


