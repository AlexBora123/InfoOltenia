/// n^2
#include <fstream>
#include <cassert>
#define DIM 100010
using namespace std;

int a[DIM], b[DIM], c[DIM], A[DIM];
int n, m, sa, sb, i, j, t, ok, P, L, p;

ifstream fin ("prieteni.in");
ofstream fout("prieteni.out");


/// copiem in b o secventa de lungime L care incepe in a la pozitia p
void copiere(int b[], int a[], int p, int L) {
    for (int i=p, j=1;j<=L; i++, j++)
        b[j] = a[i];
}

/// stergem din a o secventa de lungime L care incepe la pozitia p
/// actualizam pe n
void stergere(int a[], int n, int p, int L) {
    assert(p+L-1 <= n);
    for (int i=p, j=p+L; j<=n; i++, j++)
        a[i] = a[i+L];
}

/// aplicam sirul b de lungime m peste sirul a de lungime m din pozitia p
void aplicare(int a[], int n, int b[], int m, int p) {
    assert(p+m-1 <= n);
    for (int i=p, j=1; j<=m; i++, j++)
        a[i] += b[j];
}

int cautaPrimaDiferita(int a[], int n, int b[], int m) {
    assert(m <= n);
    int i;
    for (i=1;i<=m;i++)
        if (a[i] != b[i])
            break;
    return i;
}

int suntIdentice(int a[], int b[], int n) {
    for (int i=1;i<=n;i++)
        if (a[i]!=b[i])
            return 0;
    return 1;

}

void verificare(int p) {

}

int main () {
    for (fin>>t;t--;) {
        fin>>n;
        long long sa = 0;
        for (i=1;i<=n;i++) {
            fin>>a[i];
            sa += a[i];
        }
        fin>>m;
        long long sb = 0;
        for (i=1;i<=m;i++) {
            fin>>b[i];
            sb += b[i];
        }
        if (sa != sb) {
            fout<<"0\n";
            continue;
        }

        if (m > n) {
            fout<<"0\n";
            continue;
        }
        L = n-m;

        p = cautaPrimaDiferita(a, n, b, m);

        int ok = 0;
        if (p+L-1 < m) {
            for (i=2;i<=n-L;i++) {
                /// presupun ca extrag o secventa de la pozitia i si
                /// apoi o aplic la pozitia p
                copiere(c, a, i, L);
                copiere(A, a, 1, n);
                stergere(A, n, i, L);
                aplicare(A, m, c, L, p);
                if (suntIdentice(A, b, m)) {
                    ok = 1;
                    break;
                }
            }
            if (ok) {
                fout<<"1 "<<i<<" "<<L<<" "<<p<<"\n";
                continue;
            }
        }



        int k;
        for (k=m;k>=L;k--) {
            if (b[k] != a[n-(m-k)])
                break;
        }
        if (k < L) {
            fout<<"0\n";
            continue;
        }
        p = k-L+1;

        for (i=2;i<=n-L;i++) {
            /// presupun ca extrag o secventa de la pozitia i si
            /// apoi o aplic la pozitia p
            copiere(c, a, i, L);
            copiere(A, a, 1, n);
            stergere(A, n, i, L);
            aplicare(A, m, c, L, p);
            if (suntIdentice(A, b, m)) {
                ok = 1;
                break;
            }
        }
        if (ok) {
            fout<<"1 "<<i<<" "<<L<<" "<<p<<"\n";
        } else {
            fout<<"0\n";
        }
    }
    return 0;
}


