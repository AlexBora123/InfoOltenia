/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <fstream>
#include <iostream>
using namespace std;
ifstream fin("prieteni.in");
ofstream fout("prieteni.out");
int a[2001], b[2001], aux[2001], c[2001], n,m,T;
int main()
{
    fin>>T;
    while(T){
          T--;
          fin>>n;
          for(int i=1;i<=n;i++)
             fin>>a[i];
          fin>>m;
          for(int i=1;i<=m;i++)
             fin>>b[i];
        int k=n-m;
        int ok=0;
         for(int i=2;i<=n-k;i++){
             ok=1;
             /// extrag din pozitia i k elemente
             for(int j=1;j<=k;j++)
                 aux[j]=a[i+j-1];
             /// restrang vectorul
              int t=0;
              for(int j=1;j<i;j++)
                 c[++t]=a[j];
              for(int j=i+k;j<=n;j++)
                  c[++t]=a[j];
              /// gasec pozitia unde pot plasa
              int j=1;
              while(c[j]==b[j]&&j<=t)
                  j++;
              if(j<=t){
                  for(int st=j;st<=j+k-1&&ok==1;st++)
                     if(c[st]+aux[st-j+1]!=b[st])
                           ok=0;
                  for(int st=j+k;st<=t&&ok==1;st++)
                      if(c[st]!=b[st])
                           ok=0;
                   if(ok==1){
                         fout<<1<<" "<<i<<" "<<k<<" "<<j<<"\n";
                         break;
                   }
                 else
                   ok=0;
              }
             if(ok==1)
                break;
         }
          if(ok==0)
                 fout<<"0\n";
    }

    return 0;
}


