#include <fstream>
#include <iostream>

using namespace std;
int f[100001], sol;
void getRad(int p, int &g, int &v) {
    /// pozitia, grupul si valoarea
    g = 1;
    int s = 1;
    while (s < p) {
        g++;
        s += g;
    }
    if (s == p)
        v = g;
    else
        v = g - (s-p);
}

void getLin(int p, int &g, int &v) {
    int crt = 0;
    for (g=1;;g++)
        for (v=1;v<=g;v++) {
            crt++;
            if (crt == p)
                return;
        }
}
int st, dr, g, v, caz, gst, vst, gdr, vdr;
int main () {
    ifstream fin ("sir.in");
    ofstream fout("sir.out");
    fin>>caz>>st>>dr;
    getRad(st, gst, vst);
    getRad(dr, gdr, vdr);
    ///cout<<gst<<" "<<gdr;
    if (gst == gdr) {
        if (caz == 1) {
            fout<<vdr-vst+1<<"\n";
        } else {
            for (int i=vst;i<=vdr;i++) {
                fout<<i<<" 1"<<"\n";
            }
        }
    } else {
        if (gdr-gst >= 2) {
            int aux = (gdr-1)-(gst+1)+1;
            for (int i=1;i<=gst+1;i++)
                f[i] = aux;
            for (int i=gst+2;i<=gdr-1;i++) {
                f[i] = --aux;
            }
        }
        /// punem elementele din gst
        for (int i=vst;i<=gst;i++)
            f[i]++;
        /// punem elementele din gdr
        for (int i=1;i<=vdr;i++)
            f[i]++;
        for (int i=1;i<=50000;i++)
            if (f[i] != 0)
                sol++;
        if (caz == 1)
            fout<<sol<<"\n";
        else {
            for (int i=1;i<=50000;i++)
                if (f[i] != 0)
                    fout<<i<<" "<<f[i]<<"\n";
        }
    }
    return 0;
}

