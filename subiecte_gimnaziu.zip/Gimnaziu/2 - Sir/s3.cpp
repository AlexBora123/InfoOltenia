//timp O(sqrt(2*q))
//memorie O(1)
#include <fstream>
#include <cmath>
using namespace std;

ifstream cin("sir.in");
ofstream cout("sir.out");

int main()
{
    int c, p, q;
    cin >> c;
    cin >> p >> q;


   int nrq = sqrt(2*q); //ultima grupa completa inaintea grupei lui q
   if(nrq*(nrq+1)/2 >= q)
        nrq--;
   int elemq = q-nrq*(nrq+1)/2; //al catelea element din grupa sa este q


   int nrp = sqrt(2*p); //ultima grupa completa inaintea grupei lui p
   if(nrp*(nrp+1)/2 >= p)
        nrp--;
   int elemp = p-nrp*(nrp+1)/2; //al catelea element din grupa sa este p

    if (c == 1){
        if (nrq == nrp) //cele doua numere sunt in aceeasi grupa
            cout << elemq-elemp+1;
        else
            if(nrq == nrp+1) //sunt in grupe succesive
            {
                if(elemq >= elemp)
                    cout<<max(elemq,nrq);
                else
                    cout<<nrq - elemp+1 + elemq;
            }
            else //au cel putin o grupa intreaga intre ele
                cout<<max(nrq,elemq);
       return 0;
    }

    if(c == 2){
       int cnt = nrq+1-nrp;
       int j=nrp+1; //j este nr de elemente din grupa lui p
       for(int i=1;i<=nrq;i++){ //valorile posibile dintr-o grupa
            if(j==nrp+1 && i<elemp ) //valori posibile in grupa lui p si pozitii mai mici decat ale lui p
                if(i<=elemq)
                {
                    if(cnt>1)
                        cout <<i<<" "<<cnt-1<<"\n";
                }
                 else{
                    if(cnt >2)
                        cout<<i<<" "<<cnt-2<<"\n";
                 }


            if(j==nrp+1 && i>=elemp)//valori posibile in grupa lui p si pozitii mai mari sau egale decat ale lui p
                if(i<=elemq)
                    cout <<i<<" "<<cnt<<"\n";
                 else{
                    if(cnt>1)
                        cout<<i<<" "<<cnt-1<<"\n";
                 }


            if(j>nrp+1) //am depasit numarul de elemente din grupa lui p
                if(i<=elemq)
                    cout<<i<<" "<<cnt<<"\n";
                else
                {
                    if(cnt>1)
                         cout<<i<<" "<<cnt-1<<"\n";
                }


            if(i==j)
                cnt--,j++;

        }
        if(elemq==nrq+1)
            cout<<nrq+1<<" "<<1<<"\n";
    }
    return 0;
}


