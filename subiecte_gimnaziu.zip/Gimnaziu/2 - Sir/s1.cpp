#include <iostream>
#include<fstream>
using namespace std;
int n,p,q,c,nr;
ifstream fin("sir.in");
ofstream fout("sir.out");
int fr[100000];
int main()
{
     fin>>c>>p>>q;
     int gr1=0;
     while(1ll*gr1*(gr1+1)/2<p)
           gr1++;
    int p1=p-1ll*gr1*(gr1-1)/2;

      int gr2=0;
     while(1ll*gr2*(gr2+1)/2<q)
           gr2++;
    int p2=q-1ll*gr2*(gr2-1)/2;
     ///fout<<gr1<<" "<<gr2;
     if(c==1){
        if(gr1!=gr2){
         if(p2!=gr2)
              fout<<gr2-1;
         else
            fout<<gr2;
           return 0;
        }
        fout<<p2-p1+1;
        return 0;
     }
   if(gr1!=gr2){
     int nr=gr2-gr1-1;
     for(int i=1;i<=gr1+1;i++)
         fr[i]+=nr;
     for(int i=gr1+2;i<gr2;i++){
          nr--;
          fr[i]+=nr;
     }
     for(int i=p1;i<=gr1;i++)
          fr[i]++;
     for(int i=1;i<=p2;i++)
         fr[i]++;
   }
   else{
     for(int i=p1;i<=p2;i++)
       fr[i]++;
   }
   for(int i=1;i<=gr2;i++)
       if(fr[i]!=0)
          fout<<i<<" "<<fr[i]<<"\n";
    return 0;
}


