//timp O(q)
//memorie O(sqrt(2*q)
#include <fstream>
using namespace std;

ifstream cin("sir.in");
ofstream cout("sir.out");

int fr[50000];
int main()
{
    int c, p, q;
    cin >> c >> p >> q;

    int lin=1, x =0, xmax=0;
    for(int i = 1;i <= q; i++)
    {
        x++;
        if( i>=p )
            {
                fr[x]++;
                xmax=max(x,xmax);
            }
        if(x==lin)
            lin++,x=0;
    }

    if(c==1){
        int cnt = 0;
        for(int i=1;i<=xmax;i++)
            if(fr[i]>0)
             cnt++;
        cout << cnt ;
        return 0;
    }

    if(c==2)
    {
        for(int i=1;i<=xmax;i++)
            if(fr[i]>0)
                cout<<i<<" "<<fr[i]<<"\n";
    }

    return 0;
}


